#include<stdio.h>
int main(){
    int a=100,b,c;
    if (a>50)
    {
        b=300;
    }
    else {
        c=400;
    }
    printf("the value of b = %d and c = %d", b,c);
    return 0;
}